# 🌿 TrailMate AI

An offline-first outdoor companion powered by open-weight AI.

TrailMate helps hikers identify things they see, record nature observations, track a trail with GPS, and keep a local nature journal. The project is designed around open innovation: the AI layer can run locally through Ollama instead of sending photos and observations to a proprietary cloud AI service.

## Why open AI?

TrailMate is intended for places where connectivity may be poor or unavailable.

- **Local inference:** photos can be analyzed by a model running on your own computer/local network.
- **Privacy:** observations and photos do not need to leave your environment.
- **Model choice:** the AI adapter is separate from the UI, so the model can be changed.
- **Low recurring cost:** once a local model is installed, there is no per-image API bill.
- **Offline-first UX:** trail tracking and the journal work in the browser without an AI server.

> Important: AI identification is an assistive suggestion, not a guaranteed species identification. Do not eat, touch, or approach wildlife/plants based only on an AI result.

## Features

### MVP
- 📷 Camera/photo upload
- 🤖 Local vision AI through Ollama
- 📍 Browser GPS
- 🥾 Live trail tracking
- 📏 Distance calculation
- 📔 Local nature journal
- 💾 LocalStorage persistence
- 📶 Online/offline status
- 📱 Mobile-first responsive PWA shell
- 🔌 FastAPI REST API

## Architecture

```text
Phone / Laptop
      |
      v
 React + Vite PWA
      |
      +---- GPS / Trail / Journal ----> Local browser storage
      |
      +---- Photo --------------------> FastAPI
                                          |
                                          v
                                       Ollama
                                          |
                                   Open-weight vision model
                                          |
                                          v
                                      JSON result
```

## Project structure

```text
trailmate-ai/
├── frontend/
│   ├── public/
│   │   ├── icon.svg
│   │   ├── manifest.webmanifest
│   │   └── sw.js
│   ├── src/
│   │   ├── App.jsx
│   │   ├── main.jsx
│   │   └── styles.css
│   ├── index.html
│   ├── package.json
│   └── vite.config.js
├── backend/
│   ├── app/
│   │   ├── __init__.py
│   │   ├── config.py
│   │   ├── main.py
│   │   └── ollama.py
│   ├── .env.example
│   └── requirements.txt
├── .github/
│   └── workflows/
│       └── frontend-pages.yml
├── .gitignore
├── LICENSE
└── docker-compose.yml
```

## Requirements

- Node.js 20+
- Python 3.11+
- Optional: Ollama for local AI
- A webcam/camera if using photo capture
- HTTPS is recommended for GPS/camera on a deployed site. `localhost` works for local development.

## 1. Run the frontend

```bash
cd frontend
npm install
npm run dev
```

Open the URL shown by Vite.

## 2. Run the backend

Windows:

```powershell
cd backend
py -3.11 -m venv .venv
.venv\Scripts\activate
pip install -r requirements.txt
copy .env.example .env
uvicorn app.main:app --reload --host 0.0.0.0 --port 8000
```

Linux/macOS:

```bash
cd backend
python3 -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
cp .env.example .env
uvicorn app.main:app --reload --host 0.0.0.0 --port 8000
```

The API will be available at `http://localhost:8000`.

## 3. Configure Ollama

Install Ollama from its official site, then pull a vision-capable open-weight model that your machine can run.

Example:

```bash
ollama pull gemma3:4b
```

Then make sure Ollama is running.

Set the frontend API URL if necessary:

```text
VITE_API_URL=http://localhost:8000
```

The backend uses:

```text
OLLAMA_URL=http://localhost:11434
OLLAMA_MODEL=gemma3:4b
```

If your selected model has a different name, change `OLLAMA_MODEL`.

## 4. Using the app

### Identify
1. Open **Identify**.
2. Take a photo or choose one.
3. Press **Analyze with Local AI**.
4. TrailMate sends the image to your local FastAPI service.
5. FastAPI sends it to Ollama.
6. The response is displayed and can be saved as an observation.

### Trail
1. Open **Trail**.
2. Press **Start Trail**.
3. Allow location access.
4. Keep the page open while walking.
5. TrailMate records points locally and calculates approximate distance.
6. Press **Stop Trail** when finished.

### Journal
Saved observations and trail summaries remain in browser storage.

## Offline behavior

The PWA shell is cached after the first successful load. GPS tracking and the journal are designed to work without the Internet.

AI photo analysis is local rather than cloud-based, but the browser still needs access to the machine running the FastAPI/Ollama service. For a fully standalone phone implementation, the next version can move inference into the device/browser using WebGPU/WebAssembly.

## API

### Health

```http
GET /api/health
```

### Model information

```http
GET /api/model
```

### Identify an image

```http
POST /api/identify
Content-Type: multipart/form-data
file=<image>
```

## GitHub Pages

GitHub Pages can host the frontend because Vite creates a static production bundle.

For a repository named `trailmate-ai`, set:

```js
base: '/trailmate-ai/'
```

in `frontend/vite.config.js`.

The included GitHub Actions workflow builds and deploys the frontend.

**Important:** GitHub Pages cannot run FastAPI or Ollama. For AI identification, host the backend/Ollama service on a computer, VPS, home server, or another compatible host and set `VITE_API_URL` during the frontend build.

## Docker

The included `docker-compose.yml` starts the FastAPI service and Ollama.

```bash
docker compose up --build
```

The Ollama model is intentionally not auto-downloaded by Compose because model size varies. After the containers start:

```bash
docker exec -it trailmate-ollama ollama pull gemma3:4b
```

Then open the frontend separately with Vite, or build/serve it using your preferred static host.

## Privacy

TrailMate does not include analytics or a cloud AI API by default.

Images are sent only to the configured TrailMate backend when the user explicitly presses Analyze.

## Roadmap

- [ ] Offline map tiles
- [ ] Bird-call identification
- [ ] Plant-specific classifier
- [ ] GPX import/export
- [ ] Trail elevation
- [ ] Nearby points of interest
- [ ] Installable Android package
- [ ] Browser/device-local vision inference
- [ ] Encrypted local journal
- [ ] Community trail sharing
- [ ] Sri Lankan biodiversity dataset

## Contributing

Pull requests are welcome. Good first contributions include UI improvements, accessibility, offline map support, test coverage, additional model adapters, and localization.

## License

MIT
