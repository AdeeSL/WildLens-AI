import { useEffect, useMemo, useRef, useState } from "react";
import {
  Camera,
  CheckCircle2,
  Compass,
  Leaf,
  MapPin,
  Menu,
  NotebookPen,
  Pause,
  Play,
  RotateCcw,
  Save,
  Settings,
  ShieldCheck,
  Sparkles,
  Square,
  Trash2,
  Wifi,
  WifiOff,
  X,
} from "lucide-react";

const API_URL = import.meta.env.VITE_API_URL || "http://localhost:8000";
const STORAGE = {
  observations: "trailmate.observations",
  trail: "trailmate.trail",
};

function load(key, fallback) {
  try {
    return JSON.parse(localStorage.getItem(key)) ?? fallback;
  } catch {
    return fallback;
  }
}

function save(key, value) {
  localStorage.setItem(key, JSON.stringify(value));
}

function distanceMeters(a, b) {
  if (!a || !b) return 0;
  const R = 6371000;
  const p1 = (a.lat * Math.PI) / 180;
  const p2 = (b.lat * Math.PI) / 180;
  const dp = ((b.lat - a.lat) * Math.PI) / 180;
  const dl = ((b.lng - a.lng) * Math.PI) / 180;
  const x =
    Math.sin(dp / 2) ** 2 +
    Math.cos(p1) * Math.cos(p2) * Math.sin(dl / 2) ** 2;
  return 2 * R * Math.atan2(Math.sqrt(x), Math.sqrt(1 - x));
}

function formatDistance(meters) {
  if (meters < 1000) return `${Math.round(meters)} m`;
  return `${(meters / 1000).toFixed(2)} km`;
}

function App() {
  const [page, setPage] = useState("home");
  const [observations, setObservations] = useState(() =>
    load(STORAGE.observations, [])
  );
  const [trail, setTrail] = useState(() => load(STORAGE.trail, []));
  const [isOnline, setIsOnline] = useState(navigator.onLine);
  const [menuOpen, setMenuOpen] = useState(false);
  const [aiReady, setAiReady] = useState(false);
  const [modelName, setModelName] = useState("");
  const [location, setLocation] = useState(null);
  const [tracking, setTracking] = useState(false);
  const watchRef = useRef(null);

  useEffect(() => save(STORAGE.observations, observations), [observations]);
  useEffect(() => save(STORAGE.trail, trail), [trail]);

  useEffect(() => {
    const on = () => setIsOnline(true);
    const off = () => setIsOnline(false);
    window.addEventListener("online", on);
    window.addEventListener("offline", off);
    return () => {
      window.removeEventListener("online", on);
      window.removeEventListener("offline", off);
      if (watchRef.current) navigator.geolocation.clearWatch(watchRef.current);
    };
  }, []);

  useEffect(() => {
    fetch(`${API_URL}/api/health`)
      .then((r) => r.json())
      .then((data) => {
        setAiReady(Boolean(data?.ollama?.online));
        setModelName(data?.ollama?.configured_model || "");
      })
      .catch(() => setAiReady(false));
  }, []);

  const trailDistance = useMemo(
    () =>
      trail.reduce(
        (sum, point, index) =>
          index === 0 ? 0 : sum + distanceMeters(trail[index - 1], point),
        0
      ),
    [trail]
  );

  function startTracking() {
    if (!("geolocation" in navigator)) {
      alert("GPS is not available in this browser.");
      return;
    }

    setTracking(true);

    watchRef.current = navigator.geolocation.watchPosition(
      (position) => {
        const point = {
          lat: position.coords.latitude,
          lng: position.coords.longitude,
          accuracy: position.coords.accuracy,
          timestamp: new Date(position.timestamp).toISOString(),
        };
        setLocation(point);
        setTrail((old) => {
          const previous = old[old.length - 1];
          if (previous && distanceMeters(previous, point) < 5) return old;
          return [...old, point];
        });
      },
      (error) => {
        setTracking(false);
        alert(`GPS error: ${error.message}`);
      },
      {
        enableHighAccuracy: true,
        maximumAge: 5000,
        timeout: 15000,
      }
    );
  }

  function stopTracking() {
    if (watchRef.current) navigator.geolocation.clearWatch(watchRef.current);
    watchRef.current = null;
    setTracking(false);
  }

  function clearTrail() {
    if (confirm("Clear the current trail?")) setTrail([]);
  }

  function addObservation(result, imageDataUrl) {
    const item = {
      id: crypto.randomUUID(),
      createdAt: new Date().toISOString(),
      location,
      image: imageDataUrl,
      ...result,
    };
    setObservations((old) => [item, ...old]);
    setPage("journal");
  }

  function deleteObservation(id) {
    setObservations((old) => old.filter((item) => item.id !== id));
  }

  return (
    <div className="app-shell">
      <header className="topbar">
        <button className="icon-btn mobile-menu" onClick={() => setMenuOpen(true)}>
          <Menu size={22} />
        </button>
        <button className="brand" onClick={() => setPage("home")}>
          <span className="brand-mark"><Leaf size={20} /></span>
          <span>
            <strong>TrailMate</strong>
            <small>open AI outdoors</small>
          </span>
        </button>
        <div className="status">
          {isOnline ? <Wifi size={16} /> : <WifiOff size={16} />}
          <span>{isOnline ? "Online" : "Offline"}</span>
          <span className={`ai-dot ${aiReady ? "ready" : ""}`} />
        </div>
      </header>

      <div className="layout">
        <aside className={`sidebar ${menuOpen ? "open" : ""}`}>
          <div className="sidebar-head">
            <span>TrailMate</span>
            <button className="icon-btn close-menu" onClick={() => setMenuOpen(false)}>
              <X size={20} />
            </button>
          </div>
          <NavButton icon={<Compass />} label="Home" active={page === "home"} onClick={() => { setPage("home"); setMenuOpen(false); }} />
          <NavButton icon={<Camera />} label="Identify" active={page === "identify"} onClick={() => { setPage("identify"); setMenuOpen(false); }} />
          <NavButton icon={<MapPin />} label="My Trail" active={page === "trail"} onClick={() => { setPage("trail"); setMenuOpen(false); }} />
          <NavButton icon={<NotebookPen />} label="Nature Journal" active={page === "journal"} onClick={() => { setPage("journal"); setMenuOpen(false); }} />
          <NavButton icon={<Settings />} label="Settings" active={page === "settings"} onClick={() => { setPage("settings"); setMenuOpen(false); }} />
          <div className="sidebar-note">
            <ShieldCheck size={18} />
            <span>Local-first by design. Your journal stays in this browser.</span>
          </div>
        </aside>

        <main className="content">
          {page === "home" && (
            <Home
              isOnline={isOnline}
              aiReady={aiReady}
              modelName={modelName}
              observationCount={observations.length}
              trailDistance={trailDistance}
              onIdentify={() => setPage("identify")}
              onTrail={() => setPage("trail")}
              onJournal={() => setPage("journal")}
            />
          )}

          {page === "identify" && (
            <Identify
              aiReady={aiReady}
              modelName={modelName}
              location={location}
              onSave={addObservation}
            />
          )}

          {page === "trail" && (
            <Trail
              tracking={tracking}
              trail={trail}
              distance={trailDistance}
              location={location}
              onStart={startTracking}
              onStop={stopTracking}
              onClear={clearTrail}
            />
          )}

          {page === "journal" && (
            <Journal observations={observations} onDelete={deleteObservation} />
          )}

          {page === "settings" && (
            <SettingsPage apiUrl={API_URL} aiReady={aiReady} modelName={modelName} />
          )}
        </main>
      </div>

      <nav className="bottom-nav">
        <NavButton icon={<Compass />} label="Home" active={page === "home"} onClick={() => setPage("home")} />
        <NavButton icon={<Camera />} label="Identify" active={page === "identify"} onClick={() => setPage("identify")} />
        <NavButton icon={<MapPin />} label="Trail" active={page === "trail"} onClick={() => setPage("trail")} />
        <NavButton icon={<NotebookPen />} label="Journal" active={page === "journal"} onClick={() => setPage("journal")} />
      </nav>
    </div>
  );
}

function NavButton({ icon, label, active, onClick }) {
  return (
    <button className={`nav-btn ${active ? "active" : ""}`} onClick={onClick}>
      {icon}
      <span>{label}</span>
    </button>
  );
}

function Home({
  isOnline,
  aiReady,
  modelName,
  observationCount,
  trailDistance,
  onIdentify,
  onTrail,
  onJournal,
}) {
  return (
    <>
      <section className="hero">
        <div className="eyebrow"><Sparkles size={16} /> Open AI. Real world.</div>
        <h1>Go outside.<br /><em>Let AI come with you.</em></h1>
        <p>
          TrailMate is an offline-first outdoor companion for discovering nature,
          tracking trails, and keeping a private field journal.
        </p>
        <div className="hero-actions">
          <button className="primary-btn" onClick={onIdentify}><Camera size={19} /> Identify something</button>
          <button className="secondary-btn" onClick={onTrail}><MapPin size={19} /> Start a trail</button>
        </div>
      </section>

      <section className="status-card">
        <div>
          <span className="label">LOCAL AI</span>
          <strong>{aiReady ? "Ready to explore" : "AI server not connected"}</strong>
          <small>{aiReady ? `${modelName} · local inference` : "Trail logging and journal still work offline."}</small>
        </div>
        <div className={`big-status ${aiReady ? "good" : ""}`}>
          {aiReady ? <CheckCircle2 /> : <WifiOff />}
        </div>
      </section>

      <section className="feature-grid">
        <Feature icon={<Camera />} title="Identify" text="Use your camera and a local vision model to understand what you find." onClick={onIdentify} />
        <Feature icon={<MapPin />} title="Track" text="Record your walk with GPS. Trail points stay in your browser." onClick={onTrail} />
        <Feature icon={<NotebookPen />} title="Remember" text="Build a personal nature journal from your observations." onClick={onJournal} />
      </section>

      <section className="stats">
        <Stat value={observationCount} label="observations" />
        <Stat value={formatDistance(trailDistance)} label="current trail" />
        <Stat value={isOnline ? "Online" : "Offline"} label="connection" />
      </section>

      <section className="why-open">
        <div className="section-kicker">WHY OPEN AI?</div>
        <h2>Your trail data belongs to you.</h2>
        <p>
          TrailMate separates the AI layer from the interface so you can run an
          open-weight model locally, change models, and keep outdoor observations
          away from a proprietary AI API.
        </p>
      </section>
    </>
  );
}

function Feature({ icon, title, text, onClick }) {
  return (
    <button className="feature-card" onClick={onClick}>
      <span className="feature-icon">{icon}</span>
      <strong>{title}</strong>
      <p>{text}</p>
      <span className="learn">Open →</span>
    </button>
  );
}

function Stat({ value, label }) {
  return (
    <div className="stat">
      <strong>{value}</strong>
      <span>{label}</span>
    </div>
  );
}

function Identify({ aiReady, modelName, location, onSave }) {
  const [file, setFile] = useState(null);
  const [preview, setPreview] = useState("");
  const [result, setResult] = useState(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");

  function chooseFile(event) {
    const selected = event.target.files?.[0];
    if (!selected) return;
    setFile(selected);
    setPreview(URL.createObjectURL(selected));
    setResult(null);
    setError("");
  }

  async function analyze() {
    if (!file) return;
    setLoading(true);
    setError("");

    try {
      const form = new FormData();
      form.append("file", file);

      const response = await fetch(`${API_URL}/api/identify`, {
        method: "POST",
        body: form,
      });

      const data = await response.json();

      if (!response.ok) throw new Error(data.detail || "AI analysis failed.");

      setResult(data);
    } catch (err) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  }

  return (
    <>
      <PageTitle
        eyebrow="FIELD IDENTIFICATION"
        title="What did you find?"
        text="Take a clear photo. TrailMate sends it to your configured local AI model."
      />

      <div className="ai-banner">
        <ShieldCheck size={20} />
        <div>
          <strong>{aiReady ? "Local AI is ready" : "Connect local AI to analyze"}</strong>
          <span>{aiReady ? modelName : "Start FastAPI + Ollama on your computer/server."}</span>
        </div>
      </div>

      <div className="identify-grid">
        <div className="photo-panel">
          {preview ? (
            <img src={preview} className="preview" alt="Selected outdoor subject" />
          ) : (
            <div className="photo-placeholder">
              <Camera size={42} />
              <strong>Take a photo</strong>
              <span>Plants, birds, insects, fungi or landmarks</span>
            </div>
          )}

          <label className="primary-btn file-btn">
            <Camera size={19} /> {preview ? "Choose another" : "Take / choose photo"}
            <input
              type="file"
              accept="image/*"
              capture="environment"
              onChange={chooseFile}
              hidden
            />
          </label>

          <button
            className="secondary-btn full"
            disabled={!file || loading || !aiReady}
            onClick={analyze}
          >
            {loading ? <><RotateCcw className="spin" size={18} /> Analyzing locally...</> : <><Sparkles size={18} /> Analyze with Local AI</>}
          </button>

          {!aiReady && (
            <p className="hint">
              The journal and trail tracker work without AI. For identification,
              connect this app to your local TrailMate API.
            </p>
          )}
        </div>

        <div className="result-panel">
          {!result && !error && (
            <div className="empty-result">
              <Leaf size={30} />
              <h3>Your field note will appear here</h3>
              <p>TrailMate will return a cautious identification, visual clues, safety guidance, and a next observation tip.</p>
            </div>
          )}

          {error && (
            <div className="error-box">
              <strong>Could not analyze</strong>
              <p>{error}</p>
            </div>
          )}

          {result && (
            <div className="result">
              <div className="result-top">
                <span className="category">{result.category}</span>
                <span className="confidence">{result.confidence}% confidence</span>
              </div>
              <h2>{result.common_name}</h2>
              <em>{result.scientific_name}</em>
              <p>{result.description}</p>

              <div className="result-section">
                <strong>Field marks</strong>
                <ul>
                  {(result.field_marks || []).map((mark, i) => <li key={i}>{mark}</li>)}
                </ul>
              </div>

              <div className="safety">
                <ShieldCheck size={18} />
                <div><strong>Safety</strong><span>{result.safety}</span></div>
              </div>

              <div className="next-tip">
                <strong>Next observation</strong>
                <span>{result.next_step}</span>
              </div>

              <button
                className="primary-btn full"
                onClick={() => onSave(result, preview)}
              >
                <Save size={18} /> Save to Nature Journal
              </button>

              {location && (
                <small className="location-note">
                  Saved location: {location.lat.toFixed(5)}, {location.lng.toFixed(5)}
                </small>
              )}
            </div>
          )}
        </div>
      </div>
    </>
  );
}

function PageTitle({ eyebrow, title, text }) {
  return (
    <div className="page-title">
      <div className="section-kicker">{eyebrow}</div>
      <h1>{title}</h1>
      <p>{text}</p>
    </div>
  );
}

function Trail({ tracking, trail, distance, location, onStart, onStop, onClear }) {
  return (
    <>
      <PageTitle
        eyebrow="MY TRAIL"
        title="Walk your way."
        text="GPS points are recorded locally in this browser while you explore."
      />

      <div className="trail-controls">
        {!tracking ? (
          <button className="primary-btn" onClick={onStart}><Play size={18} /> Start Trail</button>
        ) : (
          <button className="danger-btn" onClick={onStop}><Square size={17} /> Stop Trail</button>
        )}
        <button className="secondary-btn" onClick={onClear} disabled={!trail.length}><Trash2 size={17} /> Clear</button>
      </div>

      <div className="trail-card">
        <div className="trail-map">
          {trail.length > 1 ? <TrailSvg points={trail} /> : (
            <div className="map-empty">
              <MapPin size={36} />
              <strong>{tracking ? "Waiting for GPS..." : "Your trail appears here"}</strong>
              <span>Start tracking and walk outside.</span>
            </div>
          )}
          {tracking && <span className="tracking-pill"><span /> Recording</span>}
        </div>

        <div className="trail-stats">
          <Stat value={formatDistance(distance)} label="distance" />
          <Stat value={trail.length} label="GPS points" />
          <Stat value={location ? `${location.accuracy.toFixed(0)} m` : "—"} label="accuracy" />
        </div>
      </div>

      <div className="privacy-card">
        <ShieldCheck size={20} />
        <div>
          <strong>Local trail log</strong>
          <p>Trail points are stored in your browser. They are not uploaded by this MVP.</p>
        </div>
      </div>
    </>
  );
}

function TrailSvg({ points }) {
  const minLat = Math.min(...points.map((p) => p.lat));
  const maxLat = Math.max(...points.map((p) => p.lat));
  const minLng = Math.min(...points.map((p) => p.lng));
  const maxLng = Math.max(...points.map((p) => p.lng));
  const latSpan = Math.max(maxLat - minLat, 0.0001);
  const lngSpan = Math.max(maxLng - minLng, 0.0001);

  const coords = points.map((p) => {
    const x = 30 + ((p.lng - minLng) / lngSpan) * 540;
    const y = 250 - ((p.lat - minLat) / latSpan) * 220;
    return [x, y];
  });

  const d = coords.map(([x, y], i) => `${i ? "L" : "M"} ${x.toFixed(1)} ${y.toFixed(1)}`).join(" ");

  return (
    <svg viewBox="0 0 600 280" className="trail-svg" role="img" aria-label="Recorded trail">
      <defs>
        <pattern id="grid" width="30" height="30" patternUnits="userSpaceOnUse">
          <path d="M 30 0 L 0 0 0 30" fill="none" stroke="currentColor" strokeOpacity=".08" />
        </pattern>
      </defs>
      <rect width="600" height="280" fill="url(#grid)" />
      <path d={d} fill="none" stroke="currentColor" strokeWidth="5" strokeLinecap="round" strokeLinejoin="round" />
      <circle cx={coords[0][0]} cy={coords[0][1]} r="8" className="start-dot" />
      <circle cx={coords.at(-1)[0]} cy={coords.at(-1)[1]} r="8" className="end-dot" />
    </svg>
  );
}

function Journal({ observations, onDelete }) {
  return (
    <>
      <PageTitle
        eyebrow="NATURE JOURNAL"
        title="Keep what you discover."
        text={`${observations.length} observation${observations.length === 1 ? "" : "s"} saved locally.`}
      />

      {!observations.length ? (
        <div className="empty-journal">
          <NotebookPen size={42} />
          <h3>Your journal is empty</h3>
          <p>Identify something outdoors and save it here.</p>
        </div>
      ) : (
        <div className="journal-grid">
          {observations.map((item) => (
            <article className="journal-card" key={item.id}>
              {item.image && <img src={item.image} alt="" />}
              <div className="journal-body">
                <div className="result-top">
                  <span className="category">{item.category}</span>
                  <button className="icon-btn" onClick={() => onDelete(item.id)} aria-label="Delete observation">
                    <Trash2 size={17} />
                  </button>
                </div>
                <h3>{item.common_name}</h3>
                <em>{item.scientific_name}</em>
                <p>{item.description}</p>
                {item.location && (
                  <small><MapPin size={13} /> {item.location.lat.toFixed(5)}, {item.location.lng.toFixed(5)}</small>
                )}
              </div>
            </article>
          ))}
        </div>
      )}
    </>
  );
}

function SettingsPage({ apiUrl, aiReady, modelName }) {
  return (
    <>
      <PageTitle
        eyebrow="SETTINGS"
        title="Your local setup."
        text="TrailMate is intentionally simple: browser + local API + open-weight model."
      />

      <div className="settings-list">
        <div className="setting">
          <div><strong>API endpoint</strong><span>{apiUrl}</span></div>
          <CheckCircle2 size={20} />
        </div>
        <div className="setting">
          <div><strong>Local AI</strong><span>{aiReady ? `Connected · ${modelName}` : "Not connected"}</span></div>
          {aiReady ? <CheckCircle2 size={20} /> : <WifiOff size={20} />}
        </div>
        <div className="setting">
          <div><strong>Storage</strong><span>Browser localStorage</span></div>
          <ShieldCheck size={20} />
        </div>
        <div className="setting">
          <div><strong>Privacy</strong><span>No analytics or cloud AI is included by default.</span></div>
          <ShieldCheck size={20} />
        </div>
      </div>

      <div className="setup-note">
        <strong>For a fully offline phone build</strong>
        <p>
          This MVP keeps trail/journal features offline but uses a local FastAPI
          + Ollama service for vision. A future version can move inference into
          the browser/device using WebGPU or package the model with a native app.
        </p>
      </div>
    </>
  );
}

export default App;
