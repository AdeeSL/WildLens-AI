import base64
import json
import re
from typing import Any

import httpx

from .config import settings


SYSTEM_PROMPT = """
You are TrailMate AI, an outdoor nature assistant.

Analyze the supplied image carefully. Do not pretend certainty. If the subject
cannot be identified reliably, say so.

Return ONLY valid JSON with these keys:
{
  "category": "plant|animal|bird|insect|fungus|landmark|other|unknown",
  "common_name": "string",
  "scientific_name": "string or unknown",
  "confidence": 0,
  "description": "short description",
  "field_marks": ["short visual clue"],
  "safety": "short safety note",
  "next_step": "one useful outdoor observation tip"
}

The confidence must be an integer from 0 to 100.
Never recommend consuming an unidentified plant, mushroom, or animal.
""".strip()


def _extract_json(text: str) -> dict[str, Any]:
    text = text.strip()

    if text.startswith("```"):
        text = re.sub(r"^```(?:json)?\s*", "", text, flags=re.I)
        text = re.sub(r"\s*```$", "", text)

    try:
        return json.loads(text)
    except json.JSONDecodeError:
        match = re.search(r"\{.*\}", text, flags=re.S)
        if match:
            try:
                return json.loads(match.group(0))
            except json.JSONDecodeError:
                pass

    return {
        "category": "unknown",
        "common_name": "Unable to parse model response",
        "scientific_name": "unknown",
        "confidence": 0,
        "description": text[:1000],
        "field_marks": [],
        "safety": "Do not rely on this result for identification or safety decisions.",
        "next_step": "Take another clear photo from a different angle."
    }


async def identify_image(image_bytes: bytes) -> dict[str, Any]:
    image_b64 = base64.b64encode(image_bytes).decode("utf-8")

    payload = {
        "model": settings.ollama_model,
        "stream": False,
        "messages": [
            {
                "role": "system",
                "content": SYSTEM_PROMPT,
            },
            {
                "role": "user",
                "content": "Identify and explain the main outdoor subject in this image.",
                "images": [image_b64],
            },
        ],
        "options": {
            "temperature": 0.1,
        },
    }

    async with httpx.AsyncClient(timeout=180) as client:
        response = await client.post(
            f"{settings.ollama_url.rstrip('/')}/api/chat",
            json=payload,
        )
        response.raise_for_status()
        data = response.json()

    message = data.get("message", {})
    content = message.get("content", "")
    result = _extract_json(content)

    try:
        result["confidence"] = max(0, min(100, int(result.get("confidence", 0))))
    except (TypeError, ValueError):
        result["confidence"] = 0

    return result


async def check_ollama() -> dict[str, Any]:
    async with httpx.AsyncClient(timeout=5) as client:
        response = await client.get(f"{settings.ollama_url.rstrip('/')}/api/tags")
        response.raise_for_status()
        data = response.json()

    models = [m.get("name") for m in data.get("models", [])]
    return {
        "online": True,
        "configured_model": settings.ollama_model,
        "available_models": models,
    }
