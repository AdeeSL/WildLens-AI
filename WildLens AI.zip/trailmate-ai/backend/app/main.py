from typing import Annotated

from fastapi import FastAPI, File, HTTPException, UploadFile
from fastapi.middleware.cors import CORSMiddleware

from .config import settings
from .ollama import check_ollama, identify_image

app = FastAPI(
    title="TrailMate AI API",
    version="0.1.0",
    description="Local-first outdoor AI assistant.",
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=settings.cors_list,
    allow_credentials=False,
    allow_methods=["*"],
    allow_headers=["*"],
)


@app.get("/")
async def root():
    return {
        "name": "TrailMate AI API",
        "version": "0.1.0",
        "docs": "/docs",
    }


@app.get("/api/health")
async def health():
    try:
        ollama = await check_ollama()
    except Exception as exc:
        ollama = {
            "online": False,
            "error": str(exc),
            "configured_model": settings.ollama_model,
        }

    return {
        "api": "ok",
        "ollama": ollama,
    }


@app.get("/api/model")
async def model():
    try:
        return await check_ollama()
    except Exception as exc:
        raise HTTPException(status_code=503, detail=str(exc))


@app.post("/api/identify")
async def identify(file: Annotated[UploadFile, File(...)]):
    if not file.content_type or not file.content_type.startswith("image/"):
        raise HTTPException(status_code=415, detail="Please upload an image.")

    image = await file.read()

    if len(image) > 12 * 1024 * 1024:
        raise HTTPException(status_code=413, detail="Image is larger than 12 MB.")

    try:
        result = await identify_image(image)
    except Exception as exc:
        raise HTTPException(
            status_code=503,
            detail=(
                "Local AI is unavailable. Make sure Ollama is running and the "
                f"configured model '{settings.ollama_model}' is installed. "
                f"Details: {exc}"
            ),
        )

    return result
